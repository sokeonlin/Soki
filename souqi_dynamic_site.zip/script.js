document.addEventListener("DOMContentLoaded", () => {
  fetch('products.json')
    .then(response => response.json())
    .then(products => {
      const container = document.getElementById('products-container');
      products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product';
        card.innerHTML = `
          <img src="${product.image}" alt="${product.name}" style="width:100%">
          <h3>${product.name}</h3>
          <p>${product.description}</p>
          <p>السعر: ${product.price} ريال</p>
          <button onclick="alert('أضيف ${product.name} إلى السلة')">أضف إلى السلة</button>
        `;
        container.appendChild(card);
      });
    });
});
